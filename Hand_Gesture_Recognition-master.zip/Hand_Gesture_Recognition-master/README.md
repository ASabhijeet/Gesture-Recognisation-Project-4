# Hand_Gesture_Recognition
This Project is about recognising number of fingers showing in front of live feed camera.Using Hand HaarCascade XML which is used to identify Palm. 
